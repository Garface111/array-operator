// smarthub_registry.js — GENERATED FILE. DO NOT EDIT BY HAND.
//
// Source of truth: api/data/providers/*.csv (rows with a smarthub_host).
// Regenerate:  python scripts/gen_smarthub_registry_js.py
// CI verifies this file is in sync via --check.
//
// Exposed on the global so it works in EVERY context that loads this file:
//   * content scripts + the popup (page world)  -> window.SMARTHUB_REGISTRY
//   * the background service worker (importScripts, no `window`) -> self.SMARTHUB_REGISTRY
// background.js importScripts() this for utility auto-login: it resolves a
// *.smarthub.coop login host to the right co-op CODE so the saved credential
// for that co-op is used.

(function (glob) {
  "use strict";

  // Maps *.smarthub.coop hostname → lowercase provider code (matches DB)
  const SMARTHUB_REGISTRY = {
    "4riverselectric.smarthub.coop": {
      provider: "four_rivers",
      name: "4 Rivers Electric Cooperative",
    },
    "accessenergycoop.smarthub.coop": {
      provider: "access",
      name: "Access Energy Cooperative",
    },
    "acecwi.smarthub.coop": {
      provider: "adams_columbia",
      name: "Adams-Columbia Electric Cooperative",
    },
    "acrec.smarthub.coop": {
      provider: "allamakee_clayton",
      name: "Allamakee-Clayton Electric Cooperative",
    },
    "adams.smarthub.coop": {
      provider: "adams",
      name: "Adams Electric Cooperative",
    },
    "adamsec.smarthub.coop": {
      provider: "adams_ec",
      name: "Adams Electric Cooperative",
    },
    "aec.smarthub.coop": {
      provider: "aemc",
      name: "Appalachian Electric Cooperative",
    },
    "aecimn.smarthub.coop": {
      provider: "arrowhead",
      name: "Arrowhead Electric Cooperative",
    },
    "agralite.smarthub.coop": {
      provider: "agralite",
      name: "Agralite Electric Cooperative",
    },
    "ahec.smarthub.coop": {
      provider: "mo_ahec",
      name: "Atchison-Holt Electric Cooperative",
    },
    "alfalfaelectric.smarthub.coop": {
      provider: "alfalfa",
      name: "Alfalfa Electric Cooperative",
    },
    "algerdelta.smarthub.coop": {
      provider: "algerdelta",
      name: "Alger Delta Cooperative Electric Association",
    },
    "alputilities.smarthub.coop": {
      provider: "mn_alexandria",
      name: "ALP Utilities (Alexandria)",
    },
    "anecop.smarthub.coop": {
      provider: "anec",
      name: "A&N Electric Cooperative",
    },
    "arkvalley.smarthub.coop": {
      provider: "ks_ark_valley",
      name: "Ark Valley Electric Cooperative Association",
    },
    "ashleychicot.smarthub.coop": {
      provider: "ashleychicot",
      name: "Ashley-Chicot Electric Cooperative",
    },
    "austinutilities.smarthub.coop": {
      provider: "mn_austin",
      name: "Austin Utilities",
    },
    "avecc.smarthub.coop": {
      provider: "arkvalley",
      name: "Arkansas Valley Electric Cooperative Corporation (AVECC)",
    },
    "baelectric.smarthub.coop": {
      provider: "ba_electric",
      name: "Brown-Atchison Electric Cooperative",
    },
    "baldwinemc.smarthub.coop": {
      provider: "baldwinemc",
      name: "Baldwin EMC",
    },
    "bandera.smarthub.coop": {
      provider: "bandera",
      name: "Bandera Electric Cooperative",
    },
    "barcelectric.smarthub.coop": {
      provider: "barc",
      name: "BARC Electric Cooperative",
    },
    "barronelectric.smarthub.coop": {
      provider: "barron",
      name: "Barron Electric Cooperative",
    },
    "bartlettec.smarthub.coop": {
      provider: "bartlett",
      name: "Bartlett Electric Cooperative",
    },
    "bartonelectric.smarthub.coop": {
      provider: "mo_barton_co",
      name: "Barton County Electric Cooperative",
    },
    "bayfieldelectric.smarthub.coop": {
      provider: "bayfield",
      name: "Bayfield Electric Cooperative",
    },
    "bcremc.smarthub.coop": {
      provider: "bcremc",
      name: "Bartholomew County REMC",
    },
    "bdec.smarthub.coop": {
      provider: "bdec",
      name: "Burke Divide Electric Cooperative",
    },
    "beartoothelectric.smarthub.coop": {
      provider: "beartooth",
      name: "Beartooth Electric Cooperative",
    },
    "becsc.smarthub.coop": {
      provider: "berkeley",
      name: "Berkeley Electric Cooperative",
    },
    "bedfordrec.smarthub.coop": {
      provider: "bedford_rec",
      name: "Bedford Rural Electric Cooperative",
    },
    "belmontlight.smarthub.coop": {
      provider: "belmont",
      name: "Belmont Municipal Light Department",
    },
    "beltramielectric.smarthub.coop": {
      provider: "beltrami",
      name: "Beltrami Electric Cooperative",
    },
    "bemc.smarthub.coop": {
      provider: "brunswick_emc",
      name: "Brunswick Electric Membership Corporation",
    },
    "benco.smarthub.coop": {
      provider: "benco",
      name: "BENCO Electric Cooperative",
    },
    "bentonpud.smarthub.coop": {
      provider: "benton_pud",
      name: "Benton County PUD",
    },
    "bentonrea.smarthub.coop": {
      provider: "bentonrea",
      name: "Benton County Electric System (Benton REA)",
    },
    "bentonutilities.smarthub.coop": {
      provider: "benton",
      name: "City of Benton Electric",
    },
    "bgmu.smarthub.coop": {
      provider: "bowling_green",
      name: "Bowling Green Municipal Utilities",
    },
    "bhec.smarthub.coop": {
      provider: "bhec",
      name: "Black Hills Electric Cooperative",
    },
    "bigflatelectric.smarthub.coop": {
      provider: "bigflat",
      name: "Big Flat Electric Cooperative",
    },
    "bighorncounty.smarthub.coop": {
      provider: "bighorncounty",
      name: "Big Horn County Electric Cooperative",
    },
    "blachlylane.smarthub.coop": {
      provider: "blachlylane",
      name: "Blachly-Lane Electric Cooperative",
    },
    "blockisland.smarthub.coop": {
      provider: "block_island",
      name: "Block Island Power Company",
    },
    "bluebonnet.smarthub.coop": {
      provider: "bluebonnet",
      name: "Bluebonnet Electric Cooperative",
    },
    "bluestemelectric.smarthub.coop": {
      provider: "bluestem",
      name: "Bluestem Electric Cooperative",
    },
    "booneelectric.smarthub.coop": {
      provider: "mo_boone",
      name: "Boone Electric Cooperative",
    },
    "brec.smarthub.coop": {
      provider: "mo_brec",
      name: "Black River Electric Cooperative",
    },
    "bremc.smarthub.coop": {
      provider: "boone",
      name: "Boone REMC",
    },
    "brightridge.smarthub.coop": {
      provider: "johnson_city",
      name: "Johnson City Power Board",
    },
    "broadriverelectric.smarthub.coop": {
      provider: "broad_river",
      name: "Broad River Electric Cooperative",
    },
    "btes.smarthub.coop": {
      provider: "bristol_tn",
      name: "Bristol Tennessee Essential Services",
    },
    "bueci.smarthub.coop": {
      provider: "ak_barrow",
      name: "Barrow Utilities and Electric Cooperative (BUEC)",
    },
    "butler.smarthub.coop": {
      provider: "butler",
      name: "Butler Municipal Electric Light & Power",
    },
    "butlerrec.smarthub.coop": {
      provider: "butlercounty_rec",
      name: "Butler County Rural Electric Cooperative",
    },
    "butteelectric.smarthub.coop": {
      provider: "butte_electric",
      name: "Butte Electric Cooperative",
    },
    "bvea.smarthub.coop": {
      provider: "bvea",
      name: "Bridger Valley Electric Association",
    },
    "byelectric.smarthub.coop": {
      provider: "bon_homme_yankton",
      name: "Bon Homme Yankton Electric Association",
    },
    "callawayelectric.smarthub.coop": {
      provider: "mo_callaway",
      name: "Callaway Electric Cooperative",
    },
    "camwalnet.smarthub.coop": {
      provider: "cam_wal",
      name: "Cam Wal Electric Cooperative",
    },
    "canadianvalley.smarthub.coop": {
      provider: "canadianvalley",
      name: "Canadian Valley Electric Cooperative",
    },
    "capitalelec.smarthub.coop": {
      provider: "capitalelec",
      name: "Capital Electric Cooperative",
    },
    "carbonpower.smarthub.coop": {
      provider: "carbonpower",
      name: "Carbon Power & Light",
    },
    "cavalierrural.smarthub.coop": {
      provider: "cavalierrec",
      name: "Cavalier Rural Electric Cooperative",
    },
    "cbec.smarthub.coop": {
      provider: "cbec",
      name: "Craig-Botetourt Electric Cooperative (CBEC)",
    },
    "cceci.smarthub.coop": {
      provider: "clinton_cec",
      name: "Clinton County Electric Cooperative",
    },
    "ccppd.smarthub.coop": {
      provider: "cuming_ppd",
      name: "Cuming County Public Power District",
    },
    "cdec.smarthub.coop": {
      provider: "cdec",
      name: "Continental Divide Electric Cooperative",
    },
    "cec.smarthub.coop": {
      provider: "central_sc",
      name: "Central Electric Power Cooperative",
    },
    "cecelec.smarthub.coop": {
      provider: "cherryland",
      name: "Cherryland Electric Cooperative",
    },
    "cecnet.smarthub.coop": {
      provider: "clarke",
      name: "Clarke Electric Cooperative",
    },
    "cecoop.smarthub.coop": {
      provider: "clark_wi",
      name: "Clark Electric Cooperative",
    },
    "cecpower.smarthub.coop": {
      provider: "carroll",
      name: "Carroll Electric Cooperative",
    },
    "cemc.smarthub.coop": {
      provider: "cemc",
      name: "Cumberland Electric Membership Corporation",
    },
    "central.smarthub.coop": {
      provider: "central_ec",
      name: "Central Electric Cooperative",
    },
    "centralec.smarthub.coop": {
      provider: "cec_sd",
      name: "Central Electric Cooperative",
    },
    "charlesmix.smarthub.coop": {
      provider: "charles_mix",
      name: "Charles Mix Electric Association",
    },
    "cherrytodd.smarthub.coop": {
      provider: "cherry_todd",
      name: "Cherry-Todd Electric Cooperative",
    },
    "choctawelectric.smarthub.coop": {
      provider: "choctaw",
      name: "Choctaw Electric Cooperative",
    },
    "choptankelectric.smarthub.coop": {
      provider: "choptank",
      name: "Choptank Electric Cooperative",
    },
    "cimarronelectric.smarthub.coop": {
      provider: "cimarron",
      name: "Cimarron Electric Cooperative",
    },
    "citizenselectric.smarthub.coop": {
      provider: "mo_citizens",
      name: "Citizens Electric Corporation",
    },
    "clallampud.smarthub.coop": {
      provider: "clallam_pud",
      name: "Clallam County PUD",
    },
    "clarkenergy.smarthub.coop": {
      provider: "clark_energy",
      name: "Clark Energy Cooperative",
    },
    "clarkremc.smarthub.coop": {
      provider: "clark",
      name: "Clark County REMC",
    },
    "clatskaniepud.smarthub.coop": {
      provider: "clatskanie_pud",
      name: "Clatskanie PUD",
    },
    "claverack.smarthub.coop": {
      provider: "claverack_rec",
      name: "Claverack Rural Electric Cooperative",
    },
    "claycountyelectric.smarthub.coop": {
      provider: "claycounty_ar",
      name: "Clay County Electric Cooperative",
    },
    "clayelectric.smarthub.coop": {
      provider: "clayelectric",
      name: "Clay Electric Cooperative",
    },
    "clearwaterpolk.smarthub.coop": {
      provider: "clearwater_polk",
      name: "Clearwater-Polk Electric Cooperative",
    },
    "clearwaterpower.smarthub.coop": {
      provider: "clearwater",
      name: "Clearwater Power Company",
    },
    "cloverland.smarthub.coop": {
      provider: "cloverland",
      name: "Cloverland Electric Cooperative",
    },
    "clpower.smarthub.coop": {
      provider: "clpa",
      name: "Cooperative Light & Power Association",
    },
    "clpud.smarthub.coop": {
      provider: "clpud",
      name: "Central Lincoln PUD",
    },
    "cmec.smarthub.coop": {
      provider: "cmec",
      name: "Coles-Moultrie Electric Cooperative",
    },
    "cmecinc.smarthub.coop": {
      provider: "mo_cmec",
      name: "Central Missouri Electric Cooperative",
    },
    "cmselectric.smarthub.coop": {
      provider: "cms_electric",
      name: "CMS Electric Cooperative",
    },
    "cnmec.smarthub.coop": {
      provider: "cnmec",
      name: "Central New Mexico Electric Cooperative",
    },
    "coastal.smarthub.coop": {
      provider: "coastal_al",
      name: "Coastal Electric Cooperative (AL)",
    },
    "coastalelectric.smarthub.coop": {
      provider: "coastal_electric",
      name: "Coastal Electric Cooperative",
    },
    "coastelectric.smarthub.coop": {
      provider: "coast_electric",
      name: "Coast Electric Power Association",
    },
    "cobbemc.smarthub.coop": {
      provider: "cobb_emc",
      name: "Cobb EMC",
    },
    "codingtonclarkelectric.smarthub.coop": {
      provider: "codington_clark",
      name: "Codington-Clark Electric Cooperative",
    },
    "columbiabasin.smarthub.coop": {
      provider: "columbia_basin",
      name: "Columbia Basin Electric Cooperative",
    },
    "columbiarea.smarthub.coop": {
      provider: "columbia_rea",
      name: "Columbia Rural Electric Association",
    },
    "columbuscoop.smarthub.coop": {
      provider: "columbuscoop",
      name: "Columbus Electric Cooperative",
    },
    "comelec.smarthub.coop": {
      provider: "comelec",
      name: "Community Electric Cooperative",
    },
    "como.smarthub.coop": {
      provider: "mo_como",
      name: "Co-Mo Electric Cooperative",
    },
    "concord.smarthub.coop": {
      provider: "concord",
      name: "Concord Municipal Light Plant",
    },
    "consolidatedelectric.smarthub.coop": {
      provider: "oh_consolidated",
      name: "Consolidated Cooperative",
    },
    "consolidatedelectriccoop.smarthub.coop": {
      provider: "oh_delaware_rec",
      name: "Delaware Rural Electric Cooperative",
    },
    "consumersenergy.smarthub.coop": {
      provider: "consumersenergy",
      name: "Consumers Energy (IA co-op)",
    },
    "cooksonhills.smarthub.coop": {
      provider: "cooksonhills",
      name: "Cookson Hills Electric Cooperative",
    },
    "core.smarthub.coop": {
      provider: "irea",
      name: "Intermountain Rural Electric Association",
    },
    "cornbeltenergy.smarthub.coop": {
      provider: "cornbelt",
      name: "Corn Belt Energy Corporation",
    },
    "corridorenergy.smarthub.coop": {
      provider: "corridor",
      name: "Corridor Energy Cooperative (formerly Linn County REC)",
    },
    "coserv.smarthub.coop": {
      provider: "coserv",
      name: "CoServ Electric",
    },
    "cottonelectric.smarthub.coop": {
      provider: "cotton",
      name: "Cotton Electric Cooperative",
    },
    "cowlitzpud.smarthub.coop": {
      provider: "cowlitz_pud",
      name: "Cowlitz PUD",
    },
    "cpi.smarthub.coop": {
      provider: "cpi",
      name: "Consumers Power Inc.",
    },
    "craigheadelectric.smarthub.coop": {
      provider: "craighead",
      name: "Craighead Electric Cooperative",
    },
    "crawfordelec.smarthub.coop": {
      provider: "mo_crawford",
      name: "Crawford Electric Cooperative",
    },
    "crewri.smarthub.coop": {
      provider: "pascoag",
      name: "Pascoag Utility District",
    },
    "crpud.smarthub.coop": {
      provider: "crpud",
      name: "Columbia River PUD",
    },
    "ctec.smarthub.coop": {
      provider: "ctec",
      name: "Central Texas Electric Cooperative",
    },
    "cumberlandvalley.smarthub.coop": {
      provider: "cumberland_valley",
      name: "Cumberland Valley Electric",
    },
    "custertel.smarthub.coop": {
      provider: "custertel",
      name: "Custer Telephone Cooperative (Electric Division)",
    },
    "cve.smarthub.coop": {
      provider: "chippewa_valley",
      name: "Chippewa Valley Electric Cooperative",
    },
    "cvea.smarthub.coop": {
      provider: "cvea",
      name: "Copper Valley Electric Association",
    },
    "cvec.smarthub.coop": {
      provider: "concho_valley",
      name: "Concho Valley Electric Cooperative",
    },
    "cwpower.smarthub.coop": {
      provider: "crow_wing",
      name: "Crow Wing Power",
    },
    "cwremc.smarthub.coop": {
      provider: "cwremc",
      name: "Carroll White REMC",
    },
    "dakotaelectric.smarthub.coop": {
      provider: "dakota",
      name: "Dakota Electric Association",
    },
    "dakotaenergy.smarthub.coop": {
      provider: "dakota_energy",
      name: "Dakota Energy Cooperative",
    },
    "dakotavalley.smarthub.coop": {
      provider: "dakotavalley",
      name: "Dakota Valley Electric Cooperative",
    },
    "dawsonpower.smarthub.coop": {
      provider: "dawson_ppd",
      name: "Dawson Public Power District",
    },
    "dce.smarthub.coop": {
      provider: "dce",
      name: "Delaware County Electric Cooperative",
    },
    "dcremc.smarthub.coop": {
      provider: "dcremc",
      name: "Decatur County REMC",
    },
    "decoop.smarthub.coop": {
      provider: "dec",
      name: "Delaware Electric Cooperative",
    },
    "deepeast.smarthub.coop": {
      provider: "deepeast",
      name: "Deep East Texas Electric Cooperative",
    },
    "demco.smarthub.coop": {
      provider: "demco",
      name: "Dixie Electric Membership Corporation (DEMCO)",
    },
    "dixieepa.smarthub.coop": {
      provider: "dixie_epa",
      name: "Dixie Electric Power Association",
    },
    "dixiepower.smarthub.coop": {
      provider: "dixie_power",
      name: "Dixie Power (Dixie Escalante REC)",
    },
    "dmea.smarthub.coop": {
      provider: "dmea",
      name: "Delta-Montrose Electric Association",
    },
    "dmremc.smarthub.coop": {
      provider: "dmremc",
      name: "Daviess-Martin County REMC",
    },
    "donrec.smarthub.coop": {
      provider: "doniphan",
      name: "Doniphan Electric Cooperative",
    },
    "douglaselectric.smarthub.coop": {
      provider: "douglas_sd",
      name: "Douglas Electric Cooperative",
    },
    "douglaspud.smarthub.coop": {
      provider: "douglas_pud",
      name: "Douglas County PUD",
    },
    "dsoelectric.smarthub.coop": {
      provider: "dso_electric",
      name: "DSO Electric Cooperative",
    },
    "duboisrec.smarthub.coop": {
      provider: "duboisrec",
      name: "Dubois REC",
    },
    "dunnenergy.smarthub.coop": {
      provider: "dunnenergy",
      name: "Dunn Energy Cooperative",
    },
    "easleyutilities.smarthub.coop": {
      provider: "easley",
      name: "Easley Combined Utility System",
    },
    "easterniowa.smarthub.coop": {
      provider: "easterniowa_lp",
      name: "Eastern Iowa Light & Power Cooperative",
    },
    "ecec.smarthub.coop": {
      provider: "ecec",
      name: "Eau Claire Energy Cooperative",
    },
    "ecemn.smarthub.coop": {
      provider: "east_central",
      name: "East Central Energy",
    },
    "ecirec.smarthub.coop": {
      provider: "eastcentral_ia",
      name: "East-Central Iowa Rural Electric Cooperative",
    },
    "ecoec.smarthub.coop": {
      provider: "ok_ecec",
      name: "East Central Electric Cooperative",
    },
    "eea.smarthub.coop": {
      provider: "eea",
      name: "Empire Electric Association",
    },
    "egyptian.smarthub.coop": {
      provider: "egyptian",
      name: "Egyptian Electric Cooperative Association",
    },
    "eiec.smarthub.coop": {
      provider: "eiec",
      name: "Eastern Illini Electric Cooperative",
    },
    "elkriverutilities.smarthub.coop": {
      provider: "mn_elk_river",
      name: "Elk River Municipal Utilities",
    },
    "elmhurstmutual.smarthub.coop": {
      provider: "elmhurst_mutual",
      name: "Elmhurst Mutual Power & Light",
    },
    "emec.smarthub.coop": {
      provider: "emec",
      name: "Eastern Maine Electric Cooperative",
    },
    "ememc.smarthub.coop": {
      provider: "edgecombe_martin_emc",
      name: "Edgecombe-Martin County EMC",
    },
    "energysterling.smarthub.coop": {
      provider: "sterling",
      name: "Sterling Municipal Light Department",
    },
    "energyunited.smarthub.coop": {
      provider: "energy_united",
      name: "EnergyUnited",
    },
    "enerstar.smarthub.coop": {
      provider: "enerstar",
      name: "EnerStar Electric Cooperative",
    },
    "epud.smarthub.coop": {
      provider: "epud",
      name: "Emerald People's Utility District",
    },
    "erec.smarthub.coop": {
      provider: "erec",
      name: "Escambia River Electric Cooperative (EREC)",
    },
    "erwinutilities.smarthub.coop": {
      provider: "erwin",
      name: "Erwin Utilities",
    },
    "fallriverelectric.smarthub.coop": {
      provider: "fallriver",
      name: "Fall River Rural Electric Cooperative",
    },
    "farmers.smarthub.coop": {
      provider: "farmers",
      name: "Farmers Electric Cooperative",
    },
    "farmerselectric.smarthub.coop": {
      provider: "farmers_recc",
      name: "Farmers RECC",
    },
    "farmersrec.smarthub.coop": {
      provider: "farmers_rec",
      name: "Farmers Electric Cooperative (multiple IA locations)",
    },
    "fayette.smarthub.coop": {
      provider: "fayette",
      name: "Fayette Electric Cooperative",
    },
    "fcec.smarthub.coop": {
      provider: "fannin",
      name: "Fannin County Electric Cooperative",
    },
    "fcremc.smarthub.coop": {
      provider: "fulton",
      name: "Fulton County REMC",
    },
    "fecnm.smarthub.coop": {
      provider: "nm_farmers",
      name: "Farmers' Electric Cooperative",
    },
    "femelectric.smarthub.coop": {
      provider: "fem",
      name: "FEM Electric Association",
    },
    "ferguselectric.smarthub.coop": {
      provider: "fergus",
      name: "Fergus Electric Cooperative",
    },
    "firstelectric.smarthub.coop": {
      provider: "firstelectric",
      name: "First Electric Cooperative",
    },
    "fkec.smarthub.coop": {
      provider: "fkec",
      name: "Florida Keys Electric Cooperative (FKEC)",
    },
    "flatheadelectric.smarthub.coop": {
      provider: "flathead",
      name: "Flathead Electric Cooperative",
    },
    "flinthillsrec.smarthub.coop": {
      provider: "flint_hills",
      name: "Flint Hills Rural Electric Cooperative",
    },
    "fmec.smarthub.coop": {
      provider: "freeborn_mower",
      name: "Freeborn-Mower Electric Cooperative",
    },
    "franklinpud.smarthub.coop": {
      provider: "franklin_pud",
      name: "Franklin PUD",
    },
    "franklinrec.smarthub.coop": {
      provider: "franklin_rec",
      name: "Franklin Rural Electric Cooperative",
    },
    "frea.smarthub.coop": {
      provider: "federated",
      name: "Federated Rural Electric Association",
    },
    "freestate.smarthub.coop": {
      provider: "freestate",
      name: "FreeState Electric Cooperative",
    },
    "frontierpower.smarthub.coop": {
      provider: "oh_frontierpower",
      name: "Frontier Power Company",
    },
    "garkaneenergy.smarthub.coop": {
      provider: "garkane",
      name: "Garkane Energy Cooperative",
    },
    "garlandlightpower.smarthub.coop": {
      provider: "garlandpower",
      name: "Garland Light & Power Company",
    },
    "gascosage.smarthub.coop": {
      provider: "mo_gascosage",
      name: "Gascosage Electric Cooperative",
    },
    "gbpw.smarthub.coop": {
      provider: "gaffney",
      name: "Gaffney Board of Public Works",
    },
    "gccea.smarthub.coop": {
      provider: "goodhue",
      name: "Goodhue County Cooperative Electric Association",
    },
    "gcea.smarthub.coop": {
      provider: "gcea",
      name: "Gunnison County Electric Association",
    },
    "gcec.smarthub.coop": {
      provider: "graham_az",
      name: "Graham County Electric Cooperative",
    },
    "gec.smarthub.coop": {
      provider: "greenbelt",
      name: "Greenbelt Electric Cooperative",
    },
    "ghblp.smarthub.coop": {
      provider: "grand_haven",
      name: "Grand Haven Board of Light & Power",
    },
    "ghpud.smarthub.coop": {
      provider: "grays_harbor_pud",
      name: "Grays Harbor PUD",
    },
    "gibsonconnect.smarthub.coop": {
      provider: "gemc",
      name: "Gibson Electric Membership Corporation",
    },
    "glacierelectric.smarthub.coop": {
      provider: "glacier",
      name: "Glacier Electric Cooperative",
    },
    "gladesec.smarthub.coop": {
      provider: "gladesec",
      name: "Glades Electric Cooperative",
    },
    "glenergy.smarthub.coop": {
      provider: "gle",
      name: "Great Lakes Energy Cooperative",
    },
    "glps.smarthub.coop": {
      provider: "greeneville",
      name: "Greeneville Light & Power System",
    },
    "gmenergy.smarthub.coop": {
      provider: "oh_guernsey_muskingum",
      name: "Guernsey-Muskingum Electric Cooperative",
    },
    "goldenwest.smarthub.coop": {
      provider: "goldenwest",
      name: "Goldenwest Electric Cooperative",
    },
    "grandelectric.smarthub.coop": {
      provider: "grand_electric",
      name: "Grand Electric Cooperative",
    },
    "graysoncollin.smarthub.coop": {
      provider: "grayson_collin",
      name: "Grayson-Collin Electric Cooperative",
    },
    "greenfieldin.smarthub.coop": {
      provider: "greenfield",
      name: "Greenfield Power & Light",
    },
    "gridley.smarthub.coop": {
      provider: "gridley",
      name: "Gridley Electric Utility",
    },
    "grundycountyrecia.smarthub.coop": {
      provider: "grundy",
      name: "Grundy County Rural Electric Cooperative",
    },
    "guthrierec.smarthub.coop": {
      provider: "guthrie",
      name: "Guthrie County Rural Electric Cooperative",
    },
    "gvea.smarthub.coop": {
      provider: "gvea",
      name: "Golden Valley Electric Association",
    },
    "gvec.smarthub.coop": {
      provider: "gvec",
      name: "Guadalupe Valley Electric Cooperative",
    },
    "gvp.smarthub.coop": {
      provider: "gvp",
      name: "Grand Valley Power",
    },
    "habershamemc.smarthub.coop": {
      provider: "habersham_emc",
      name: "Habersham EMC",
    },
    "hamiltonelectric.smarthub.coop": {
      provider: "oh_hamilton",
      name: "Hamilton Municipal Electric",
    },
    "hannibalbpw.smarthub.coop": {
      provider: "hannibal_bpw",
      name: "Hannibal Board of Public Works",
    },
    "harmonelectric.smarthub.coop": {
      provider: "harmon",
      name: "Harmon Electric Cooperative",
    },
    "harneyelectric.smarthub.coop": {
      provider: "harney",
      name: "Harney Electric Cooperative",
    },
    "harrisonrea.smarthub.coop": {
      provider: "hrea",
      name: "Harrison Rural Electrification Association (HREA)",
    },
    "haywoodemc.smarthub.coop": {
      provider: "haywood_emc",
      name: "Haywood EMC",
    },
    "hcelectric.smarthub.coop": {
      provider: "hcelectric",
      name: "Hill County Electric Cooperative",
    },
    "hcrec.smarthub.coop": {
      provider: "harrison_rec",
      name: "Harrison County Rural Electric Cooperative",
    },
    "hdelectric.smarthub.coop": {
      provider: "hd_electric",
      name: "H-D Electric Cooperative",
    },
    "heartlandpower.smarthub.coop": {
      provider: "heartland_power",
      name: "Heartland Power Cooperative",
    },
    "heartlandrec.smarthub.coop": {
      provider: "heartland",
      name: "Heartland Rural Electric Cooperative",
    },
    "hemc.smarthub.coop": {
      provider: "halifax_emc",
      name: "Halifax Electric Membership Corporation",
    },
    "hendrickspower.smarthub.coop": {
      provider: "hendrickspower",
      name: "Hendricks Power Cooperative",
    },
    "henrycountyremc.smarthub.coop": {
      provider: "henrycountyremc",
      name: "Henry County REMC",
    },
    "hermistonenergy.smarthub.coop": {
      provider: "hermiston_energy",
      name: "Hermiston Energy Services",
    },
    "hged.smarthub.coop": {
      provider: "holyoke",
      name: "Holyoke Gas & Electric Department",
    },
    "highplainspower.smarthub.coop": {
      provider: "highplainspower",
      name: "High Plains Power",
    },
    "highwestenergy.smarthub.coop": {
      provider: "highwestenergy",
      name: "High West Energy",
    },
    "hilco.smarthub.coop": {
      provider: "hilco",
      name: "Hilco Electric Cooperative",
    },
    "hoec.smarthub.coop": {
      provider: "mo_hoec",
      name: "Howell-Oregon Electric Cooperative",
    },
    "holston.smarthub.coop": {
      provider: "holston",
      name: "Holston Electric Cooperative",
    },
    "holycross.smarthub.coop": {
      provider: "holycross",
      name: "Holy Cross Energy",
    },
    "homeworks.smarthub.coop": {
      provider: "homeworks",
      name: "HomeWorks Tri-County Electric Cooperative",
    },
    "hopewl.smarthub.coop": {
      provider: "hope",
      name: "City of Hope Electric",
    },
    "hotec.smarthub.coop": {
      provider: "hotec",
      name: "Heart of Texas Electric Cooperative",
    },
    "howardelectric.smarthub.coop": {
      provider: "mo_howard",
      name: "Howard Electric Cooperative",
    },
    "hrec.smarthub.coop": {
      provider: "hood_river",
      name: "Hood River Electric & Internet Co-op",
    },
    "hull.smarthub.coop": {
      provider: "hull",
      name: "Hull Municipal Lighting Plant",
    },
    "hwecoop.smarthub.coop": {
      provider: "oh_holmeswayne",
      name: "Holmes-Wayne Electric Cooperative",
    },
    "iclp.smarthub.coop": {
      provider: "idaho_county",
      name: "Idaho County Light & Power Cooperative",
    },
    "ieca.smarthub.coop": {
      provider: "mo_ieca",
      name: "Intercounty Electric Cooperative",
    },
    "iecok.smarthub.coop": {
      provider: "indian",
      name: "Indian Electric Cooperative",
    },
    "ilec.smarthub.coop": {
      provider: "iowalakes",
      name: "Iowa Lakes Electric Cooperative",
    },
    "inlandpower.smarthub.coop": {
      provider: "inland_power",
      name: "Inland Power & Light",
    },
    "insidepassageelectric.smarthub.coop": {
      provider: "ipec",
      name: "Inside Passage Electric Cooperative",
    },
    "intercountyenergy.smarthub.coop": {
      provider: "inter_county",
      name: "Inter-County Energy Cooperative",
    },
    "itascamantrap.smarthub.coop": {
      provider: "itasca_mantrap",
      name: "Itasca-Mantrap Cooperative Electrical Association",
    },
    "jackelec.smarthub.coop": {
      provider: "wi_jackson",
      name: "Jackson Electric Cooperative",
    },
    "jacksonemc.smarthub.coop": {
      provider: "jackson_emc",
      name: "Jackson EMC",
    },
    "jacksonenergy.smarthub.coop": {
      provider: "jackson_energy",
      name: "Jackson Energy Cooperative",
    },
    "jacksonremc.smarthub.coop": {
      provider: "jacksonremc",
      name: "Jackson County REMC",
    },
    "jasper.smarthub.coop": {
      provider: "jasper",
      name: "Jasper Municipal Electric",
    },
    "jayremc.smarthub.coop": {
      provider: "jayremc",
      name: "Jay County REMC",
    },
    "jce.smarthub.coop": {
      provider: "jocarroll",
      name: "Jo-Carroll Energy",
    },
    "jcremc.smarthub.coop": {
      provider: "jcremc",
      name: "Johnson County REMC",
    },
    "jeffpud.smarthub.coop": {
      provider: "jefferson_pud",
      name: "Jefferson County PUD",
    },
    "jrec.smarthub.coop": {
      provider: "jrec",
      name: "Jump River Electric Cooperative",
    },
    "karnesec.smarthub.coop": {
      provider: "karnes",
      name: "Karnes Electric Cooperative",
    },
    "kayelectric.smarthub.coop": {
      provider: "kay",
      name: "Kay Electric Cooperative",
    },
    "kcelectric.smarthub.coop": {
      provider: "kcelectric",
      name: "K.C. Electric Association",
    },
    "kec.smarthub.coop": {
      provider: "kec",
      name: "Kootenai Electric Cooperative",
    },
    "kecsd.smarthub.coop": {
      provider: "kingsbury",
      name: "Kingsbury Electric Cooperative",
    },
    "kemelectric.smarthub.coop": {
      provider: "kemelectric",
      name: "KEM Electric Cooperative",
    },
    "kenergycorp.smarthub.coop": {
      provider: "kenergy",
      name: "Kenergy Corp.",
    },
    "kiamichielectric.smarthub.coop": {
      provider: "kiamichi",
      name: "Kiamichi Electric Cooperative",
    },
    "kiuc.smarthub.coop": {
      provider: "kiuc",
      name: "Kauai Island Utility Cooperative (KIUC)",
    },
    "klickitatpud.smarthub.coop": {
      provider: "klickitat_pud",
      name: "Klickitat PUD",
    },
    "klpd.smarthub.coop": {
      provider: "klpd",
      name: "Kennebunk Light & Power District",
    },
    "kodiakelectric.smarthub.coop": {
      provider: "kea",
      name: "Kodiak Electric Association",
    },
    "kpcoop.smarthub.coop": {
      provider: "kandiyohi",
      name: "Kandiyohi Power Cooperative",
    },
    "kpub.smarthub.coop": {
      provider: "kerrville",
      name: "Kerrville Public Utility Board",
    },
    "kvremc.smarthub.coop": {
      provider: "kvremc",
      name: "Kankakee Valley REMC",
    },
    "kwh.smarthub.coop": {
      provider: "kwh",
      name: "Cass County Electric Cooperative",
    },
    "lacledeelectric.smarthub.coop": {
      provider: "mo_laclede",
      name: "Laclede Electric Cooperative",
    },
    "lacreek.smarthub.coop": {
      provider: "lacreek",
      name: "Lacreek Electric Association",
    },
    "lakecountrypower.smarthub.coop": {
      provider: "lake_country",
      name: "Lake Country Power",
    },
    "lakeregion.smarthub.coop": {
      provider: "lake_region",
      name: "Lake Region Electric Cooperative",
    },
    "lakeviewlight.smarthub.coop": {
      provider: "lakeview_light",
      name: "Lakeview Light & Power",
    },
    "lamarelectric.smarthub.coop": {
      provider: "lamar",
      name: "Lamar County Electric Cooperative",
    },
    "laneelectric.smarthub.coop": {
      provider: "lane_electric",
      name: "Lane Electric Cooperative",
    },
    "lanescott.smarthub.coop": {
      provider: "lane_scott",
      name: "Lane-Scott Electric Cooperative",
    },
    "lburgus.smarthub.coop": {
      provider: "lawrenceburg",
      name: "Lawrenceburg Utility Systems",
    },
    "lcec.smarthub.coop": {
      provider: "lamb_county",
      name: "Lamb County Electric Cooperative",
    },
    "lcecswfl.smarthub.coop": {
      provider: "lcec",
      name: "Lee County Electric Cooperative (LCEC)",
    },
    "lcpd1.smarthub.coop": {
      provider: "lcpd",
      name: "Lincoln County Power District No. 1",
    },
    "lcpud.smarthub.coop": {
      provider: "lewis_pud",
      name: "Lewis County PUD",
    },
    "lcpw.smarthub.coop": {
      provider: "sc_laurens",
      name: "City of Laurens",
    },
    "leacountyelectric.smarthub.coop": {
      provider: "nm_lcec",
      name: "Lea County Electric Cooperative (NM)",
    },
    "lebanonutilities.smarthub.coop": {
      provider: "lebanon",
      name: "Lebanon Utilities",
    },
    "lewiscountyrec.smarthub.coop": {
      provider: "mo_lewis_county",
      name: "Lewis County Rural Electric Cooperative",
    },
    "lighthouse.smarthub.coop": {
      provider: "lighthouse",
      name: "Lighthouse Electric Cooperative",
    },
    "lincolnelectric.smarthub.coop": {
      provider: "lincoln",
      name: "Lincoln Electric Cooperative",
    },
    "llec.smarthub.coop": {
      provider: "lyon_lincoln",
      name: "Lyon-Lincoln Electric Cooperative",
    },
    "lmre.smarthub.coop": {
      provider: "oh_lorain_medina",
      name: "Lorain-Medina Rural Electric Cooperative",
    },
    "lmud.smarthub.coop": {
      provider: "lassen",
      name: "Lassen Municipal Utility District",
    },
    "lpea.smarthub.coop": {
      provider: "lpea",
      name: "La Plata Electric Association",
    },
    "lrec.smarthub.coop": {
      provider: "lrec",
      name: "Lake Region Electric Association",
    },
    "lreci.smarthub.coop": {
      provider: "little_river",
      name: "Little River Electric Cooperative",
    },
    "lrecok.smarthub.coop": {
      provider: "lakeregion_ok",
      name: "Lake Region Electric Cooperative",
    },
    "ludlow.smarthub.coop": {
      provider: "ludlow",
      name: "Village of Ludlow Electric Light Department",
    },
    "lumbeeriver.smarthub.coop": {
      provider: "lumbee_river_emc",
      name: "Lumbee River EMC",
    },
    "lvenergy.smarthub.coop": {
      provider: "lvenergy",
      name: "Lower Valley Energy",
    },
    "lvrecc.smarthub.coop": {
      provider: "licking_valley",
      name: "Licking Valley RECC",
    },
    "lynchesriver.smarthub.coop": {
      provider: "lynches_river",
      name: "Lynches River Electric Cooperative",
    },
    "lyntegar.smarthub.coop": {
      provider: "lyntegar",
      name: "Lyntegar Electric Cooperative",
    },
    "maelectric.smarthub.coop": {
      provider: "maelectric",
      name: "Middle Alabama Electric Cooperative",
    },
    "magnoliaepa.smarthub.coop": {
      provider: "magnolia_epa",
      name: "Magnolia Electric Power Association",
    },
    "mariasriverec.smarthub.coop": {
      provider: "mariasriver",
      name: "Marias River Electric Cooperative",
    },
    "masonpud1.smarthub.coop": {
      provider: "mason_pud_1",
      name: "Mason County PUD 1",
    },
    "masonpud3.smarthub.coop": {
      provider: "mason_pud_3",
      name: "Mason County PUD 3",
    },
    "mblp.smarthub.coop": {
      provider: "marquette_blp",
      name: "Marquette Board of Light & Power",
    },
    "mcconeelectric.smarthub.coop": {
      provider: "mccone",
      name: "McCone Electric Cooperative",
    },
    "mcdonoughpower.smarthub.coop": {
      provider: "mcdonough",
      name: "McDonough Power Cooperative",
    },
    "mcec.smarthub.coop": {
      provider: "mcec_il",
      name: "Monroe County Electric Co-Operative",
    },
    "mceci.smarthub.coop": {
      provider: "mcec",
      name: "Mississippi County Electric Cooperative",
    },
    "mcecoop.smarthub.coop": {
      provider: "mid_carolina",
      name: "Mid-Carolina Electric Cooperative",
    },
    "mckenzieelectric.smarthub.coop": {
      provider: "mckenzieelectric",
      name: "McKenzie Electric Cooperative",
    },
    "mcleanelectric.smarthub.coop": {
      provider: "mcleanelectric",
      name: "McLean Electric Cooperative",
    },
    "mcleodcoop.smarthub.coop": {
      provider: "mcleod",
      name: "McLeod Cooperative Power Association",
    },
    "mcphersonpower.smarthub.coop": {
      provider: "mcpherson",
      name: "City of McPherson Electric Department",
    },
    "mcpower.smarthub.coop": {
      provider: "mcminnville_or",
      name: "McMinnville Water & Light",
    },
    "mcrea.smarthub.coop": {
      provider: "mcrea",
      name: "Morgan County Rural Electric Association",
    },
    "mea.smarthub.coop": {
      provider: "mea",
      name: "Matanuska Electric Association",
    },
    "mec.smarthub.coop": {
      provider: "mo_macon",
      name: "Macon Electric Cooperative",
    },
    "meccoop.smarthub.coop": {
      provider: "missoula",
      name: "Missoula Electric Cooperative",
    },
    "meckelec.smarthub.coop": {
      provider: "meckelec",
      name: "Mecklenburg Electric Cooperative",
    },
    "medinaec.smarthub.coop": {
      provider: "medina",
      name: "Medina Electric Cooperative",
    },
    "meeker.smarthub.coop": {
      provider: "meeker",
      name: "Meeker Cooperative",
    },
    "mge.smarthub.coop": {
      provider: "moreau_grand",
      name: "Moreau-Grand Electric Cooperative",
    },
    "midlandpower.smarthub.coop": {
      provider: "midland_power",
      name: "Midland Power Cooperative",
    },
    "midstateelectric.smarthub.coop": {
      provider: "midstate",
      name: "Midstate Electric Cooperative",
    },
    "midwestrec.smarthub.coop": {
      provider: "oh_midwest",
      name: "Midwest Electric",
    },
    "mienergy.smarthub.coop": {
      provider: "mienergy",
      name: "MiEnergy Cooperative",
    },
    "missionvalleypower.smarthub.coop": {
      provider: "mvp",
      name: "Mission Valley Power",
    },
    "mlea.smarthub.coop": {
      provider: "mlea",
      name: "Moon Lake Electric Association",
    },
    "mlecmn.smarthub.coop": {
      provider: "mille_lacs",
      name: "Mille Lacs Energy Cooperative",
    },
    "mnvalleyrec.smarthub.coop": {
      provider: "mn_valley_lp",
      name: "Minnesota Valley Cooperative Light & Power Association",
    },
    "mohaveelectric.smarthub.coop": {
      provider: "mohave",
      name: "Mohave Electric Cooperative",
    },
    "morec.smarthub.coop": {
      provider: "mo_rural",
      name: "Missouri Rural Electric Cooperative",
    },
    "morgransou.smarthub.coop": {
      provider: "morgransou",
      name: "Mor-Gran-Sou Electric Cooperative",
    },
    "mpd.smarthub.coop": {
      provider: "marlboro",
      name: "Marlboro Electric Cooperative",
    },
    "mpw.smarthub.coop": {
      provider: "muscatine_muni",
      name: "Muscatine Power & Water",
    },
    "mtcpu.smarthub.coop": {
      provider: "il_mt_carmel",
      name: "City of Mt. Carmel Municipal Utilities",
    },
    "mtemc.smarthub.coop": {
      provider: "mtemc",
      name: "Middle Tennessee Electric Membership Corporation",
    },
    "murrayky.smarthub.coop": {
      provider: "murray_electric",
      name: "Murray Electric System",
    },
    "mvea.smarthub.coop": {
      provider: "mvea",
      name: "Mountain View Electric Association",
    },
    "mvec.smarthub.coop": {
      provider: "magoffin_valley",
      name: "Magoffin Valley Electric Cooperative",
    },
    "mwec.smarthub.coop": {
      provider: "nd_mwec",
      name: "Mountrail-Williams Electric Cooperative",
    },
    "mwpower.smarthub.coop": {
      provider: "mwpower",
      name: "Mt. Wheeler Power",
    },
    "mycentral.smarthub.coop": {
      provider: "centralrural",
      name: "Central Rural Electric Cooperative",
    },
    "myec.smarthub.coop": {
      provider: "myec",
      name: "Mid-Yellowstone Electric Cooperative",
    },
    "myelectric.smarthub.coop": {
      provider: "sdcea",
      name: "Sangre de Cristo Electric Association",
    },
    "myrec.smarthub.coop": {
      provider: "myrec",
      name: "Rappahannock Electric Cooperative (REC)",
    },
    "myremc.smarthub.coop": {
      provider: "orange",
      name: "Orange County REMC",
    },
    "navarroec.smarthub.coop": {
      provider: "navarro",
      name: "Navarro County Electric Cooperative",
    },
    "navopache.smarthub.coop": {
      provider: "navopache",
      name: "Navopache Electric Cooperative",
    },
    "nceci.smarthub.coop": {
      provider: "nceci",
      name: "North Central Electric Cooperative",
    },
    "ncelec.smarthub.coop": {
      provider: "oh_northcentral",
      name: "North Central Electric Cooperative",
    },
    "neelectric.smarthub.coop": {
      provider: "neoc",
      name: "Northeast Oklahoma Electric Cooperative",
    },
    "nemahamarshall.smarthub.coop": {
      provider: "nemaha_marshall",
      name: "Nemaha-Marshall Electric Cooperative",
    },
    "newenterpriserec.smarthub.coop": {
      provider: "new_enterprise_rec",
      name: "New Enterprise Rural Electric Cooperative",
    },
    "newmac.smarthub.coop": {
      provider: "mo_newmac",
      name: "New-Mac Electric Cooperative",
    },
    "newportutilities.smarthub.coop": {
      provider: "newport",
      name: "Newport Utilities",
    },
    "nfecoop.smarthub.coop": {
      provider: "northfork",
      name: "Northfork Electric Cooperative",
    },
    "nhec.smarthub.coop": {
      provider: "nhec",
      name: "New Hampshire Electric Cooperative",
    },
    "ninnescah.smarthub.coop": {
      provider: "ninnescah",
      name: "Ninnescah Electric Cooperative",
    },
    "niobraraelectric.smarthub.coop": {
      provider: "niobrara_ea",
      name: "Niobrara Electric Association",
    },
    "nli.smarthub.coop": {
      provider: "nli",
      name: "Northern Lights Inc.",
    },
    "nlr.smarthub.coop": {
      provider: "northlittlerock",
      name: "North Little Rock Electric",
    },
    "nnec.smarthub.coop": {
      provider: "nnec",
      name: "Northern Neck Electric Cooperative (NNEC)",
    },
    "nobleremc.smarthub.coop": {
      provider: "nobleremc",
      name: "Noble REMC",
    },
    "noblesce.smarthub.coop": {
      provider: "nobles",
      name: "Nobles Cooperative Electric",
    },
    "nodakelectric.smarthub.coop": {
      provider: "nodakelectric",
      name: "Nodak Electric Cooperative",
    },
    "nolinrecc.smarthub.coop": {
      provider: "nolin_recc",
      name: "Nolin RECC",
    },
    "norriselectric.smarthub.coop": {
      provider: "norris",
      name: "Norris Electric Cooperative",
    },
    "norrisppd.smarthub.coop": {
      provider: "norris_ppd",
      name: "Norris Public Power District",
    },
    "northcentralelectric.smarthub.coop": {
      provider: "northcentral_ec",
      name: "Northcentral Electric Cooperative",
    },
    "northernelectric.smarthub.coop": {
      provider: "northern_electric",
      name: "Northern Electric Cooperative",
    },
    "northstarelectric.smarthub.coop": {
      provider: "north_star",
      name: "North Star Electric Cooperative",
    },
    "northwesternrec.smarthub.coop": {
      provider: "northwestern_rec",
      name: "Northwestern Rural Electric Cooperative",
    },
    "norval.smarthub.coop": {
      provider: "norval",
      name: "NorVal Electric Cooperative",
    },
    "novec.smarthub.coop": {
      provider: "novec",
      name: "Northern Virginia Electric Cooperative (NOVEC)",
    },
    "nplains.smarthub.coop": {
      provider: "nplains",
      name: "Northern Plains Electric Cooperative",
    },
    "nremc.smarthub.coop": {
      provider: "northeastern",
      name: "Northeastern REMC",
    },
    "nrppd.smarthub.coop": {
      provider: "northwest_rppd",
      name: "Northwest Rural Public Power District",
    },
    "ntec.smarthub.coop": {
      provider: "nortex",
      name: "Nortex Electric Cooperative",
    },
    "nueceselectric.smarthub.coop": {
      provider: "nueces",
      name: "Nueces Electric Cooperative",
    },
    "nushagakelectric.smarthub.coop": {
      provider: "netc",
      name: "Nushagak Electric & Telephone Cooperative",
    },
    "nvemc.smarthub.coop": {
      provider: "niobrara_valley_emc",
      name: "Niobrara Valley Electric Membership Corporation",
    },
    "nvrec.smarthub.coop": {
      provider: "nishnabotna_rec",
      name: "Nishnabotna Valley Rural Electric Cooperative",
    },
    "nwascopud.smarthub.coop": {
      provider: "northern_wasco_pud",
      name: "Northern Wasco County PUD",
    },
    "nwec.smarthub.coop": {
      provider: "nwec",
      name: "Northwestern Electric Cooperative",
    },
    "nwelectric.smarthub.coop": {
      provider: "nw_electric",
      name: "Northwest Electric Cooperative",
    },
    "nwrec.smarthub.coop": {
      provider: "northwest_rec",
      name: "North West Rural Electric Cooperative",
    },
    "oaheelectric.smarthub.coop": {
      provider: "oahe",
      name: "Oahe Electric Cooperative",
    },
    "oakdalerec.smarthub.coop": {
      provider: "oakdale",
      name: "Oakdale Electric Cooperative",
    },
    "ocontoelectric.smarthub.coop": {
      provider: "oconto",
      name: "Oconto Electric Cooperative",
    },
    "ohopmutual.smarthub.coop": {
      provider: "ohop_mutual",
      name: "Ohop Mutual Light Company",
    },
    "okanoganpud.smarthub.coop": {
      provider: "okanogan_pud",
      name: "Okanogan County PUD",
    },
    "okcoop.smarthub.coop": {
      provider: "okcoop",
      name: "Oklahoma Electric Cooperative",
    },
    "ontorea.smarthub.coop": {
      provider: "ontonagon",
      name: "Ontonagon County REA",
    },
    "opalco.smarthub.coop": {
      provider: "opalco",
      name: "OPALCO (Orcas Power & Light Cooperative)",
    },
    "osagevalley.smarthub.coop": {
      provider: "mo_osage_valley",
      name: "Osage Valley Electric Cooperative",
    },
    "otero.smarthub.coop": {
      provider: "otero",
      name: "Otero County Electric Cooperative",
    },
    "our.smarthub.coop": {
      provider: "cecc",
      name: "Claiborne Electric Cooperative",
    },
    "owatonnautilities.smarthub.coop": {
      provider: "mn_owatonna",
      name: "Owatonna Public Utilities",
    },
    "ozarkborder.smarthub.coop": {
      provider: "mo_ozark_border",
      name: "Ozark Border Electric Cooperative",
    },
    "ozarkelectric.smarthub.coop": {
      provider: "mo_ozark",
      name: "Ozark Electric Cooperative",
    },
    "ozarksecc.smarthub.coop": {
      provider: "ozarks",
      name: "Ozarks Electric Cooperative",
    },
    "parisbpu.smarthub.coop": {
      provider: "paris",
      name: "Paris Board of Public Utilities",
    },
    "pbutilities.smarthub.coop": {
      provider: "poplar_bluff",
      name: "Poplar Bluff Municipal Utilities",
    },
    "pcemc.smarthub.coop": {
      provider: "pcemc",
      name: "Pointe Coupee Electric Membership Corporation",
    },
    "pec.smarthub.coop": {
      provider: "pec",
      name: "Pedernales Electric Cooperative",
    },
    "peedeeelectric.smarthub.coop": {
      provider: "pee_dee",
      name: "Pee Dee Electric Cooperative",
    },
    "pellacea.smarthub.coop": {
      provider: "pella_coop",
      name: "Pella Cooperative Electric Association",
    },
    "pemc.smarthub.coop": {
      provider: "piedmont_emc",
      name: "Piedmont Electric Membership Corporation",
    },
    "penlight.smarthub.coop": {
      provider: "peninsula_light",
      name: "Peninsula Light Company",
    },
    "peopleselectric.smarthub.coop": {
      provider: "peopleselectric",
      name: "People's Electric Cooperative",
    },
    "peoplesrec.smarthub.coop": {
      provider: "peoples_energy",
      name: "People's Energy Cooperative",
    },
    "pgec.smarthub.coop": {
      provider: "pgec",
      name: "Prince George Electric Cooperative",
    },
    "pieg.smarthub.coop": {
      provider: "pieg",
      name: "Presque Isle Electric & Gas Co-op",
    },
    "piercepepin.smarthub.coop": {
      provider: "piercepepin",
      name: "Pierce Pepin Cooperative Services",
    },
    "pioneerec.smarthub.coop": {
      provider: "oh_pioneerec",
      name: "Pioneer Rural Electric Cooperative",
    },
    "pioneerelectriccom.smarthub.coop": {
      provider: "pioneer_electric",
      name: "Pioneer Electric Cooperative",
    },
    "pioneerelectriccoop.smarthub.coop": {
      provider: "ks_pioneer",
      name: "Pioneer Electric Cooperative (KS)",
    },
    "piquaoh.smarthub.coop": {
      provider: "oh_piqua",
      name: "Piqua Municipal Power System",
    },
    "pjecc.smarthub.coop": {
      provider: "pjecc",
      name: "Petit Jean Electric Cooperative",
    },
    "pkmcoop.smarthub.coop": {
      provider: "pkm",
      name: "PKM Electric Cooperative",
    },
    "planters.smarthub.coop": {
      provider: "planters_emc",
      name: "Planters EMC",
    },
    "polkburnett.smarthub.coop": {
      provider: "polkburnett",
      name: "Polk-Burnett Electric Cooperative",
    },
    "popud.smarthub.coop": {
      provider: "pend_oreille_pud",
      name: "Pend Oreille PUD",
    },
    "ppec.smarthub.coop": {
      provider: "ppec",
      name: "Paulding Putnam Electric Cooperative",
    },
    "prairieenergy.smarthub.coop": {
      provider: "prairie",
      name: "Prairie Energy Cooperative",
    },
    "prairielandelectric.smarthub.coop": {
      provider: "prairie_land",
      name: "Prairie Land Electric Cooperative",
    },
    "preco.smarthub.coop": {
      provider: "preco",
      name: "Peace River Electric Cooperative (PRECO)",
    },
    "prema.smarthub.coop": {
      provider: "prema",
      name: "Panhandle Rural Electric Membership Association",
    },
    "priceelectric.smarthub.coop": {
      provider: "priceelectric",
      name: "Price Electric Cooperative",
    },
    "psrec.smarthub.coop": {
      provider: "psrec",
      name: "Plumas-Sierra Rural Electric Cooperative",
    },
    "pulaskielectric.smarthub.coop": {
      provider: "pulaski",
      name: "Pulaski Electric System",
    },
    "pvrea.smarthub.coop": {
      provider: "pvrea",
      name: "Poudre Valley Rural Electric Association",
    },
    "rallscountyelectric.smarthub.coop": {
      provider: "mo_ralls_county",
      name: "Ralls County Electric Cooperative",
    },
    "ravallielectric.smarthub.coop": {
      provider: "ravalli",
      name: "Ravalli Electric Cooperative",
    },
    "rcec.smarthub.coop": {
      provider: "rcec",
      name: "Roosevelt County Electric Cooperative",
    },
    "rcelectric.smarthub.coop": {
      provider: "rusk",
      name: "Rusk County Electric Cooperative",
    },
    "reaenergy.smarthub.coop": {
      provider: "rea_energy",
      name: "REA Energy Cooperative",
    },
    "recc.smarthub.coop": {
      provider: "recc_il",
      name: "Rural Electric Convenience Cooperative (RECC)",
    },
    "recok.smarthub.coop": {
      provider: "rural",
      name: "Rural Electric Cooperative",
    },
    "redlakeelectric.smarthub.coop": {
      provider: "red_lake",
      name: "Red Lake Electric Cooperative",
    },
    "redwoodelectric.smarthub.coop": {
      provider: "redwood",
      name: "Redwood Electric Cooperative",
    },
    "reedsburgutility.smarthub.coop": {
      provider: "reedsburg",
      name: "Reedsburg Utility Commission",
    },
    "rgec.smarthub.coop": {
      provider: "rgec",
      name: "Rio Grande Electric Cooperative",
    },
    "richec.smarthub.coop": {
      provider: "richland",
      name: "Richland Electric Cooperative",
    },
    "riverlandenergy.smarthub.coop": {
      provider: "riverlandenergy",
      name: "Riverland Energy Cooperative",
    },
    "rmec.smarthub.coop": {
      provider: "rmec",
      name: "Rich Mountain Electric Cooperative",
    },
    "roanokecooperative.smarthub.coop": {
      provider: "roanoke_emc",
      name: "Roanoke Electric Cooperative",
    },
    "rock.smarthub.coop": {
      provider: "rock",
      name: "Rock Energy Cooperative",
    },
    "rollinghills.smarthub.coop": {
      provider: "rolling_hills",
      name: "Rolling Hills Electric Cooperative",
    },
    "roseauelectric.smarthub.coop": {
      provider: "roseau",
      name: "Roseau Electric Cooperative",
    },
    "rosebudcoop.smarthub.coop": {
      provider: "rosebud",
      name: "Rosebud Electric Cooperative",
    },
    "roughriderelectric.smarthub.coop": {
      provider: "roughriderelectric",
      name: "Roughrider Electric Cooperative",
    },
    "rpl.smarthub.coop": {
      provider: "richmond",
      name: "Richmond Power & Light",
    },
    "rrelectric.smarthub.coop": {
      provider: "rrelectric",
      name: "Raft River Rural Electric Co-op",
    },
    "rrvcoop.smarthub.coop": {
      provider: "red_river",
      name: "Red River Valley Cooperative Power Association",
    },
    "rrvrea.smarthub.coop": {
      provider: "rrvrea",
      name: "Red River Valley Electric Cooperative",
    },
    "rscpa.smarthub.coop": {
      provider: "renville_sibley",
      name: "Renville-Sibley Cooperative Power Association",
    },
    "rse.smarthub.coop": {
      provider: "rse",
      name: "RushShelby Energy",
    },
    "runestoneelectric.smarthub.coop": {
      provider: "runestone",
      name: "Runestone Electric Association",
    },
    "rvec.smarthub.coop": {
      provider: "raccoonvalley",
      name: "Raccoon Valley Electric Cooperative",
    },
    "sacosage.smarthub.coop": {
      provider: "mo_sac_osage",
      name: "Sac Osage Electric Cooperative",
    },
    "salemelectric.smarthub.coop": {
      provider: "salem_electric",
      name: "Salem Electric",
    },
    "samhouston.smarthub.coop": {
      provider: "sam_houston",
      name: "Sam Houston Electric Cooperative",
    },
    "sanpatricioelectric.smarthub.coop": {
      provider: "san_patricio",
      name: "San Patricio Electric Cooperative",
    },
    "santee.smarthub.coop": {
      provider: "santee",
      name: "Santee Electric Cooperative",
    },
    "sawnee.smarthub.coop": {
      provider: "sawnee_emc",
      name: "Sawnee EMC",
    },
    "sbec.smarthub.coop": {
      provider: "sbec",
      name: "San Bernard Electric Cooperative",
    },
    "sbmu.smarthub.coop": {
      provider: "sikeston_bmu",
      name: "Sikeston Board of Municipal Utilities",
    },
    "scaec.smarthub.coop": {
      provider: "scaec",
      name: "South Central Arkansas Electric Cooperative",
    },
    "scecnet.smarthub.coop": {
      provider: "stcroix",
      name: "St. Croix Electric Cooperative",
    },
    "sec.smarthub.coop": {
      provider: "sec",
      name: "Southside Electric Cooperative",
    },
    "secoenergy.smarthub.coop": {
      provider: "seco",
      name: "Sumter Electric Cooperative (SECO)",
    },
    "secpa.smarthub.coop": {
      provider: "secpa",
      name: "Southeast Colorado Power Association",
    },
    "sedgwickcountyelectric.smarthub.coop": {
      provider: "sedgwick_county",
      name: "Sedgwick County Electric Cooperative",
    },
    "seecoop.smarthub.coop": {
      provider: "mt_seco",
      name: "Southeast Electric Cooperative",
    },
    "seiec.smarthub.coop": {
      provider: "seiec",
      name: "SouthEastern Illinois Electric Cooperative",
    },
    "seiremc.smarthub.coop": {
      provider: "seiremc",
      name: "Southeastern Indiana REMC",
    },
    "selco.smarthub.coop": {
      provider: "shrewsbury",
      name: "Shrewsbury Electric & Cable Operations",
    },
    "semano.smarthub.coop": {
      provider: "mo_semano",
      name: "Se-Ma-No Electric Cooperative",
    },
    "semoelectric.smarthub.coop": {
      provider: "mo_semo",
      name: "SEMO Electric Cooperative",
    },
    "shakopeeutilities.smarthub.coop": {
      provider: "mn_shakopee",
      name: "Shakopee Public Utilities Commission",
    },
    "shelbyelectric.smarthub.coop": {
      provider: "oh_shelby",
      name: "Shelby Municipal Electric",
    },
    "shelbyenergy.smarthub.coop": {
      provider: "shelby_energy",
      name: "Shelby Energy Cooperative",
    },
    "sheridanelectric.smarthub.coop": {
      provider: "sheridan",
      name: "Sheridan Electric Cooperative",
    },
    "siea.smarthub.coop": {
      provider: "siea",
      name: "San Isabel Electric Association",
    },
    "siec.smarthub.coop": {
      provider: "siec",
      name: "Southern Illinois Electric Cooperative",
    },
    "sierraelectric.smarthub.coop": {
      provider: "sierra",
      name: "Sierra Electric Cooperative",
    },
    "singingriver.smarthub.coop": {
      provider: "singing_river",
      name: "Singing River Electric Cooperative",
    },
    "siouxvalleyenergy.smarthub.coop": {
      provider: "sioux_valley",
      name: "Sioux Valley Energy",
    },
    "sirec.smarthub.coop": {
      provider: "sirec",
      name: "Southern Indiana REC",
    },
    "skamaniapud.smarthub.coop": {
      provider: "skamania_pud",
      name: "Skamania County PUD",
    },
    "skrecc.smarthub.coop": {
      provider: "south_kentucky",
      name: "South Kentucky RECC",
    },
    "slemco.smarthub.coop": {
      provider: "slemco",
      name: "South Louisiana Electric Membership Corporation (SLEMCO)",
    },
    "slopeelectric.smarthub.coop": {
      provider: "slopeelectric",
      name: "Slope Electric Cooperative",
    },
    "slvrec.smarthub.coop": {
      provider: "slvrec",
      name: "San Luis Valley Rural Electric Cooperative",
    },
    "smpa.smarthub.coop": {
      provider: "smpa",
      name: "San Miguel Power Association",
    },
    "somersetrec.smarthub.coop": {
      provider: "somerset_rec",
      name: "Somerset Rural Electric Cooperative",
    },
    "southcentralelectric.smarthub.coop": {
      provider: "south_central",
      name: "South Central Electric Association",
    },
    "southcentralpower.smarthub.coop": {
      provider: "oh_southcentral",
      name: "South Central Power Company",
    },
    "southeasternelectric.smarthub.coop": {
      provider: "southeastern",
      name: "Southeastern Electric Cooperative",
    },
    "southwestepa.smarthub.coop": {
      provider: "southwest_epa",
      name: "Southwest Mississippi Electric Power Association",
    },
    "springgrove.smarthub.coop": {
      provider: "mn_spring_grove",
      name: "City of Spring Grove",
    },
    "sre.smarthub.coop": {
      provider: "scenic_rivers",
      name: "Scenic Rivers Energy Cooperative",
    },
    "srec.smarthub.coop": {
      provider: "id_srec",
      name: "Salmon River Electric Cooperative",
    },
    "ssemc.smarthub.coop": {
      provider: "snapping_shoals_emc",
      name: "Snapping Shoals Electric Membership Corporation (SSEMC)",
    },
    "ssvec.smarthub.coop": {
      provider: "ssvec",
      name: "Sulphur Springs Valley Electric Cooperative (SSVEC)",
    },
    "stearnselectric.smarthub.coop": {
      provider: "stearns",
      name: "Stearns Electric Association",
    },
    "steubenrec.smarthub.coop": {
      provider: "srec",
      name: "Steuben Rural Electric Cooperative",
    },
    "stoweelectric.smarthub.coop": {
      provider: "stowe",
      name: "Village of Stowe Electric Department",
    },
    "sucocoop.smarthub.coop": {
      provider: "sumner_cowley",
      name: "Sumner-Cowley Electric Cooperative",
    },
    "sud.smarthub.coop": {
      provider: "starkville_es",
      name: "Starkville Electric System",
    },
    "sullivancorec.smarthub.coop": {
      provider: "sullivan_rec",
      name: "Sullivan County Rural Electric Cooperative",
    },
    "sunriverec.smarthub.coop": {
      provider: "sunriver",
      name: "Sun River Electric Cooperative",
    },
    "svalleyec.smarthub.coop": {
      provider: "svec_tn",
      name: "Sequachee Valley Electric Cooperative",
    },
    "svec.smarthub.coop": {
      provider: "surprise_valley",
      name: "Surprise Valley Electrification Corp",
    },
    "sveccoop.smarthub.coop": {
      provider: "svec_fl",
      name: "Suwannee Valley Electric Cooperative (SVEC)",
    },
    "swce.smarthub.coop": {
      provider: "steele_waseca",
      name: "Steele-Waseca Cooperative Electric",
    },
    "swiarec.smarthub.coop": {
      provider: "southwestiowa",
      name: "Southwest Iowa Rural Electric Cooperative",
    },
    "swre.smarthub.coop": {
      provider: "swre",
      name: "Southwest Rural Electric Association",
    },
    "swrea.smarthub.coop": {
      provider: "swrea",
      name: "Southwest Arkansas Electric Cooperative",
    },
    "syemc.smarthub.coop": {
      provider: "surry_yadkin_emc",
      name: "Surry-Yadkin EMC",
    },
    "tannerelectric.smarthub.coop": {
      provider: "tanner_electric",
      name: "Tanner Electric Cooperative",
    },
    "taylorelectric.smarthub.coop": {
      provider: "wi_taylor",
      name: "Taylor Electric Cooperative",
    },
    "tcec.smarthub.coop": {
      provider: "ok_tcec",
      name: "Tri County Electric Cooperative",
    },
    "tcecfl.smarthub.coop": {
      provider: "tcec",
      name: "Tri-County Electric Cooperative",
    },
    "tcectexas.smarthub.coop": {
      provider: "tcec_tx",
      name: "Tri-County Electric Cooperative",
    },
    "tcrecc.smarthub.coop": {
      provider: "taylor_electric",
      name: "Taylor County RECC",
    },
    "tdpud.smarthub.coop": {
      provider: "tdpud",
      name: "Truckee Donner Public Utility District",
    },
    "teammidwest.smarthub.coop": {
      provider: "midwest_energy",
      name: "Midwest Energy & Communications",
    },
    "tecmi.smarthub.coop": {
      provider: "tecmi",
      name: "Thumb Electric Cooperative",
    },
    "theenergycoop.smarthub.coop": {
      provider: "oh_tec",
      name: "The Energy Cooperative",
    },
    "threeriverselectric.smarthub.coop": {
      provider: "mo_three_rivers",
      name: "Three Rivers Electric Cooperative",
    },
    "tipmont.smarthub.coop": {
      provider: "tipmont",
      name: "Tipmont REMC",
    },
    "tiprec.smarthub.coop": {
      provider: "tip_rec",
      name: "T.I.P. Rural Electric Cooperative",
    },
    "toddwadena.smarthub.coop": {
      provider: "todd_wadena",
      name: "Todd-Wadena Electric Cooperative",
    },
    "tombigbee.smarthub.coop": {
      provider: "tombigbee",
      name: "Tombigbee Electric Cooperative",
    },
    "tongueriverelectric.smarthub.coop": {
      provider: "tongueriver",
      name: "Tongue River Electric Cooperative",
    },
    "tpud.smarthub.coop": {
      provider: "tpud",
      name: "Tillamook People's Utility District",
    },
    "traverseelectric.smarthub.coop": {
      provider: "traverse",
      name: "Traverse Electric Cooperative",
    },
    "trico.smarthub.coop": {
      provider: "trico",
      name: "Trico Electric Cooperative",
    },
    "tricountycoop.smarthub.coop": {
      provider: "tri_county",
      name: "Tri-County Electric Cooperative",
    },
    "tricountyrec.smarthub.coop": {
      provider: "tri_county_rec",
      name: "Tri-County Rural Electric Cooperative",
    },
    "trinitypud.smarthub.coop": {
      provider: "trinitypud",
      name: "Trinity Public Utilities District",
    },
    "tristate.smarthub.coop": {
      provider: "tri_state_emc",
      name: "Tri-State EMC",
    },
    "tvec.smarthub.coop": {
      provider: "trinity_valley",
      name: "Trinity Valley Electric Cooperative",
    },
    "twinvalleyelectric.smarthub.coop": {
      provider: "twin_valley",
      name: "Twin Valley Electric Cooperative",
    },
    "twinvalleysppd.smarthub.coop": {
      provider: "twinvalley_ppd",
      name: "Twin Valley Public Power District",
    },
    "ueci.smarthub.coop": {
      provider: "mo_ueci",
      name: "United Electric Cooperative",
    },
    "umatillaelectric.smarthub.coop": {
      provider: "umatilla_electric",
      name: "Umatilla Electric Cooperative",
    },
    "unitedelectric.smarthub.coop": {
      provider: "unitedelectric",
      name: "United Electric Cooperative",
    },
    "unitedpa.smarthub.coop": {
      provider: "united_ec",
      name: "United Electric Cooperative",
    },
    "unitedpower.smarthub.coop": {
      provider: "unitedpower",
      name: "United Power",
    },
    "ure.smarthub.coop": {
      provider: "oh_unionrec",
      name: "Union Rural Electric Cooperative",
    },
    "urecc.smarthub.coop": {
      provider: "upshur",
      name: "Upshur-Rural Electric Cooperative",
    },
    "valleyrec.smarthub.coop": {
      provider: "valley_rec",
      name: "Valley Rural Electric Cooperative",
    },
    "vea.smarthub.coop": {
      provider: "vea",
      name: "Valley Electric Association",
    },
    "veccoop.smarthub.coop": {
      provider: "vigilante",
      name: "Vigilante Electric Cooperative",
    },
    "verendrye.smarthub.coop": {
      provider: "verendrye",
      name: "Verendrye Electric Cooperative",
    },
    "vermontelectric.smarthub.coop": {
      provider: "vec",
      name: "Vermont Electric Cooperative",
    },
    "vernonelectric.smarthub.coop": {
      provider: "vernonelectric",
      name: "Vernon Electric Cooperative",
    },
    "victoriaelectric.smarthub.coop": {
      provider: "victoria",
      name: "Victoria Electric Cooperative",
    },
    "victoryelectric.smarthub.coop": {
      provider: "victory",
      name: "Victory Electric Cooperative",
    },
    "villageofenosburgfalls.smarthub.coop": {
      provider: "enosburg",
      name: "Village of Enosburg Falls",
    },
    "villageofhydepark.smarthub.coop": {
      provider: "hyde_park",
      name: "Village of Hyde Park",
    },
    "volunteer.smarthub.coop": {
      provider: "volunteer",
      name: "Volunteer Energy Cooperative",
    },
    "vvec.smarthub.coop": {
      provider: "vvec",
      name: "Verdigris Valley Electric Cooperative",
    },
    "wabash.smarthub.coop": {
      provider: "wabash",
      name: "Wabash County REMC",
    },
    "warrenec.smarthub.coop": {
      provider: "warren_ec",
      name: "Warren Electric Cooperative",
    },
    "washingtonelectric.smarthub.coop": {
      provider: "wec",
      name: "Washington Electric Co-op",
    },
    "washingtonemc.smarthub.coop": {
      provider: "washington_emc",
      name: "Washington EMC",
    },
    "waynewhitecoop.smarthub.coop": {
      provider: "wayne_white",
      name: "Wayne-White Counties Electric Cooperative",
    },
    "wbmlp.smarthub.coop": {
      provider: "west_boylston",
      name: "West Boylston Municipal Lighting Plant",
    },
    "wcec.smarthub.coop": {
      provider: "wharton",
      name: "Wharton County Electric Cooperative",
    },
    "websterec.smarthub.coop": {
      provider: "mo_webster",
      name: "Webster Electric Cooperative",
    },
    "weci.smarthub.coop": {
      provider: "oh_washingtonec",
      name: "Washington Electric Cooperative",
    },
    "wemc.smarthub.coop": {
      provider: "wake_emc",
      name: "Wake Electric Membership Corporation",
    },
    "westcentralelectric.smarthub.coop": {
      provider: "mo_west_central",
      name: "West Central Electric",
    },
    "westerncoop.smarthub.coop": {
      provider: "western_coop",
      name: "Western Cooperative Electric Association",
    },
    "westoregon.smarthub.coop": {
      provider: "west_oregon",
      name: "West Oregon Electric Cooperative",
    },
    "westriver.smarthub.coop": {
      provider: "west_river",
      name: "West River Electric Association",
    },
    "wheatbelt.smarthub.coop": {
      provider: "wheatbelt_ppd",
      name: "Wheat Belt Public Power District",
    },
    "wheatland.smarthub.coop": {
      provider: "wheatland",
      name: "Wheatland Electric Cooperative",
    },
    "whetstone.smarthub.coop": {
      provider: "whetstone",
      name: "Whetstone Valley Electric Cooperative",
    },
    "whiteriver.smarthub.coop": {
      provider: "mo_white_river",
      name: "White River Valley Electric Cooperative",
    },
    "wildriceelectric.smarthub.coop": {
      provider: "wild_rice",
      name: "Wild Rice Electric Cooperative",
    },
    "withlacoochee.smarthub.coop": {
      provider: "wrec",
      name: "Withlacoochee River Electric Cooperative (WREC)",
    },
    "wmu.smarthub.coop": {
      provider: "mn_willmar",
      name: "Willmar Municipal Utilities",
    },
    "woodburyrec.smarthub.coop": {
      provider: "woodbury",
      name: "Woodbury County Rural Electric Cooperative",
    },
    "wrea.smarthub.coop": {
      provider: "wrea_co",
      name: "White River Electric Association",
    },
    "wrecc.smarthub.coop": {
      provider: "warren_recc",
      name: "Warren RECC",
    },
    "wrwwlc.smarthub.coop": {
      provider: "wisconsin_rapids",
      name: "Wisconsin Rapids Water Works & Lighting",
    },
    "wste.smarthub.coop": {
      provider: "wstec",
      name: "Washington-St. Tammany Electric Cooperative, Inc.",
    },
    "wwvremc.smarthub.coop": {
      provider: "wwvremc",
      name: "Whitewater Valley REMC",
    },
    "yvea.smarthub.coop": {
      provider: "yvea",
      name: "Yampa Valley Electric Association",
    },
    "yvec.smarthub.coop": {
      provider: "yvec",
      name: "Yellowstone Valley Electric Cooperative",
    },
    "ywelectric.smarthub.coop": {
      provider: "ywelectric",
      name: "Y-W Electric Association",
    },
  };

  // Detect provider from the current page's hostname.
  // Unknown *.smarthub.coop hosts get a DETERMINISTIC discovered code
  // ("sh_<subdomain>") instead of masquerading as VEC — the backend mints
  // the identical code from user.hostname (api/adapters/smarthub.py
  // derive_provider_from_host), records the sighting, and alerts us to
  // promote the utility to the catalog. Data flows correctly on the very
  // first login from a brand-new co-op.
  function detectProvider(hostname) {
    const host = hostname.toLowerCase();
    const entry = SMARTHUB_REGISTRY[host];
    if (entry) return entry;
    if (host.endsWith(".smarthub.coop")) {
      const sub = host.slice(0, -".smarthub.coop".length);
      const code = sub.replace(/[^a-z0-9]+/g, "_").replace(/^_+|_+$/g, "").slice(0, 37);
      console.info(
        `[EnergyAgent] New SmartHub host: ${host} — capturing under ` +
          `discovered code sh_${code}. It will be promoted to the catalog automatically.`
      );
      return {
        provider: "sh_" + code,
        name: sub.replace(/[-.]+/g, " ").replace(/\b\w/g, (c) => c.toUpperCase()) + " (SmartHub)",
        discovered: true,
      };
    }
    return null;
  }

  // Resolve a *.smarthub.coop hostname to its co-op CODE (or null). Thin wrapper
  // over detectProvider used by the background service worker's utility
  // auto-login: given a SmartHub login URL's host, return the co-op code so the
  // matching saved credential (keyed by co-op code) is used. Covers known hosts
  // AND any new co-op via the deterministic sh_<subdomain> fallback.
  function codeForHost(hostname) {
    const e = detectProvider(String(hostname || "").toLowerCase());
    return e ? e.provider : null;
  }

  // Expose on the global of WHATEVER context loaded this file: `window` in the
  // page/content-script/popup world, `self`/`globalThis` in the service worker
  // (which importScripts() this — there is no `window` there).
  glob.SMARTHUB_REGISTRY = SMARTHUB_REGISTRY;
  glob.detectSmartHubProvider = detectProvider;
  glob.smartHubCodeForHost = codeForHost;
})(typeof self !== "undefined" ? self : (typeof window !== "undefined" ? window : globalThis));
